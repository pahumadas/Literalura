package com.alura.literalura.service;

import com.alura.literalura.dto.RespuestaGutendex;

public interface ApiService {
    RespuestaGutendex buscarLibros(String titulo);
}
